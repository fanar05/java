/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package hungerstatus;
import java.util.Scanner;
/**
 *
 * @author RC_Student_lab
 */
public class HungerStatus {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
     Scanner scanner = new Scanner(System.in);

        System.out.print("What is your name? ");
        String name = scanner.nextLine().trim();
        
        System.out.print("What is your favorite meal? ");
        String favoriteMeal = scanner.nextLine().trim();

     
        
        String input;

       
        while (true) {
            System.out.print("Are you hungry? (yes/no): ");
            input = scanner.nextLine().trim().toLowerCase();
            switch (input) {
                case "yes" -> System.out.println("Here's your favorite meal: " + favoriteMeal );
                case "no" -> {
                    System.out.println("You're full now. Have a pleasant day! 😊");
                    break;
             }
                default -> System.out.println("Please answer with 'yes' or 'no'.");
            }
        }

      
    }
}
    

